package model;

public class Friend {

	private int id;
	private int uid1;
	private int uid2;
	private int state;
	public Friend() {
	}
	public int getUid1() {
		return uid1;
	}


	public void setUid1(int uid1) {
		this.uid1 = uid1;
	}


	public int getUid2() {
		return uid2;
	}


	public void setUid2(int uid2) {
		this.uid2 = uid2;
	}


	public int getState() {
		return state;
	}


	public void setState(int state) {
		this.state = state;
	}



 

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
 
}
