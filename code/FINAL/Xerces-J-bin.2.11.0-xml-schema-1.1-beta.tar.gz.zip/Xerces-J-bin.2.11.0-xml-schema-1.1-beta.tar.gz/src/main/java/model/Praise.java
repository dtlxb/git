package model;

public class Praise {

	private int id;
	private int pid;
	private int rid;
	private String username;

	public Praise() {
	}
	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}
 
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public int getPid() {
		return pid;
	}


	public void setPid(int pid) {
		this.pid = pid;
	}


	public int getRid() {
		return rid;
	}


	public void setRid(int uid) {
		this.rid = uid;
	}

 
 
}
